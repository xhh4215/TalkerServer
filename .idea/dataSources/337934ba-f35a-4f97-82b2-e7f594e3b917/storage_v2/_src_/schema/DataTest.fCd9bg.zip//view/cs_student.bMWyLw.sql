create view cs_student as
select `datatest`.`student`.`Sno`  AS `Sname`,
       `datatest`.`student`.`Sage` AS `Sage`,
       `datatest`.`student`.`Sex`  AS `Sex`
from `datatest`.`student`
where (`datatest`.`student`.`Sage` = '12');

